#!/bin/bash
# Opcional: faz o jogo funcionar SEM internet. Rode uma vez (precisa de internet) antes de gerar o APK.
set -e
A=app/src/main/assets; mkdir -p $A/libs
curl -L -o $A/libs/three.min.js https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
curl -L -o $A/libs/GLTFLoader.js https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/GLTFLoader.js
curl -L -o $A/libs/Tone.js https://cdnjs.cloudflare.com/ajax/libs/tone/14.8.49/Tone.js
curl -L -o $A/libs/tailwind.js https://cdn.tailwindcss.com
sed -i 's#https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js#libs/three.min.js#; s#https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/GLTFLoader.js#libs/GLTFLoader.js#; s#https://cdnjs.cloudflare.com/ajax/libs/tone/14.8.49/Tone.js#libs/Tone.js#; s#https://cdn.tailwindcss.com#libs/tailwind.js#' $A/index.html
echo "Pronto: o jogo agora usa as bibliotecas locais."
